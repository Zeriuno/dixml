# XML : Dictionnaire

L’objectif de se devoir est de construire un ressource dictionnairique multilingue sur un sujet précis (un sport, une discipline, …) que vous choisirez. Ce travail est à rendre pour le 14 Mai.

* [x] Étape 1: `dictionnaire.dtd`
* [x] Étape 2: Étape 3: `source.xml`; `recupcontenu2.xq`; `dictionnaire.xml`
* [ ] Étape 4
* [ ] Étape 5



## Étape 4

En vous inspirant du code donné ci après, interfacez votre dictionnaire via le serveur web de basex.

— Placer le script dans le dossier webapp du dossier basex ; — lancer le serveur (basexhttp ou basexhttp.bat) ;
— dans un navigateur taper l’URL : `http://localhost:8984/rest?run=testparam.xq&mot=coucou&method=html`

Avec le fichier testparam.xq suivant :
```
declare variable $mot as xs:string external;
<html>
<head>
<title>test</title>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
</head>
<body>
<ul>
mot : {$mot}
</ul>
</body>
</html>
```

### Instructions
### Questions

## Étape 5

Ajouter une page HTML avec un formulaire afin d’offrir une interface d’interrogation de votre dictionnaire semblable à ce qui est présenté [ici](./apercu.png).

### Instructions

Quelque chose dans ce genre:
```
<input name="" maxlength="" placeholder="Terme à chercher" type="search"></input>
<button type="submit">Rechercher</button>
```

Comment ça fonctionne?
Probablement lors du POST, le serveur de baseX récupère la valeur saisie (on va la nommer `$valeur`)et renvoie l'utilisateur vers
```
http://localhost:8984/rest?run=testparam.xq&mot=valeur&method=html
```

### Questions

* Si la valeur saisie n'est pas la bonne (pas présente dans le dictionnaire), que se passe-t-il, le serveur renvoie-t-il une erreur 404? Faut-il dans ce cas personnaliser la page?
* Songer à la conversion: l'utilisateur saisit en UTF-8, l'espace de nommage de HTML est plus restreint. Est-ce que baseX s'en charge?
